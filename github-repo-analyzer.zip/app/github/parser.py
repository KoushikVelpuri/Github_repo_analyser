from urllib.parse import urlparse

def parse_repo_url(url: str):
    path = urlparse(url).path.strip("/")
    owner, repo = path.split("/")[:2]
    return owner, repo
