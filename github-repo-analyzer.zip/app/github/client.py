from github import Github
from app.config import GITHUB_TOKEN

gh = Github(GITHUB_TOKEN)

def fetch_repo(owner: str, repo: str):
    return gh.get_repo(f"{owner}/{repo}")

def fetch_file_tree(repo):
    tree = repo.get_git_tree(repo.default_branch, recursive=True)
    return [f.path for f in tree.tree]
