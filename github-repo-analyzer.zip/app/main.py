from fastapi import FastAPI
from app.services.analyze_repo import analyze_repo

app = FastAPI(title="GitHub Repo Analyzer")

@app.post("/analyze")
def analyze(payload: dict):
    return analyze_repo(payload["repo_url"])
