from app.github.parser import parse_repo_url
from app.github.client import fetch_repo, fetch_file_tree
from app.analyzers.stack_detector import detect_stack
from app.analyzers.structure import analyze_structure
from app.analyzers.metrics import repo_metrics
from app.llm.reasoning import generate_improvements

def analyze_repo(repo_url: str):
    owner, repo_name = parse_repo_url(repo_url)
    repo = fetch_repo(owner, repo_name)
    files = fetch_file_tree(repo)

    stack = detect_stack(files)
    structure = analyze_structure(files)
    metrics = repo_metrics(files)

    improvements = generate_improvements({
        "stack": stack,
        "architecture": structure,
        "metrics": metrics
    })

    return {
        "tech_stack": stack,
        "structure": structure,
        "metrics": metrics,
        "improvements": improvements
    }
