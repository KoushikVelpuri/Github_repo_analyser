from collections import Counter

def analyze_structure(files: list[str]) -> dict:
    depth = max(len(f.split("/")) for f in files)
    folders = Counter(f.split("/")[0] for f in files if "/" in f)

    architecture = "unknown"

    if "controllers" in folders and "services" in folders:
        architecture = "Layered Architecture"

    if "components" in folders and "hooks" in folders:
        architecture = "Component-Based Frontend"

    return {
        "architecture": architecture,
        "max_depth": depth,
        "top_level_folders": folders.most_common(5)
    }
