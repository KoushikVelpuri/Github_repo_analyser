def detect_stack(files: list[str]) -> dict:
    stack = set()

    if "package.json" in files:
        stack.add("Node.js")

    if "requirements.txt" in files or "pyproject.toml" in files:
        stack.add("Python")

    if any(f.endswith(".tsx") for f in files):
        stack.add("React")

    if "Dockerfile" in files:
        stack.add("Docker")

    if ".github/workflows" in " ".join(files):
        stack.add("CI/CD")

    return {
        "primary_stack": list(stack),
        "confidence": "high"
    }
