def repo_metrics(files: list[str]) -> dict:
    return {
        "file_count": len(files),
        "python_files": len([f for f in files if f.endswith(".py")]),
        "js_files": len([f for f in files if f.endswith(".js")])
    }
