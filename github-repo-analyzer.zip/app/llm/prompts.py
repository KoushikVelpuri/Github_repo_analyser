IMPROVEMENT_PROMPT = """
You are a senior software architect.

Tech Stack:
{stack}

Architecture:
{architecture}

Metrics:
{metrics}

Suggest:
1. Code quality improvements
2. Architecture improvements
3. DevOps improvements
4. Security concerns

Be concise and actionable.
"""
