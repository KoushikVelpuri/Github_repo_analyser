from openai import OpenAI
from app.llm.prompts import IMPROVEMENT_PROMPT

client = OpenAI()

def generate_improvements(summary: dict):
    prompt = IMPROVEMENT_PROMPT.format(**summary)

    response = client.chat.completions.create(
        model="gpt-4.1-mini",
        messages=[{"role": "user", "content": prompt}]
    )

    return response.choices[0].message.content
